function r = calculateAngle()
	Sin of a point in x,y

hypotenuseSq = 0; hypotenuse = 0;
centerX = 0 ; positionX = 3
centerY = 0 ; positionY = 4

adjacent = positionY - centerY;
opposite = positionX - centerX;

adjacent
opposite

hypotenuseSq = (adjacent ^ 2 + opposite ^ 2);
hypotenuseSq

hypotenuse = sqrt( hypotenuseSq);
hypotenuse

sinTheta = opposite/hypotenuse;
sinTheta

theta = asind(sinTheta);
theta

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Function: calculateAngle
%
% Called From: doVideoAnalysis, doImageAnalysis.
% Returns: an integer between 0 and 359 (Angle).
% Description: Takes an arrow and returns the angle from the target center when the target is flattened.
%
% PSEUDOCODE:
%
% calculateAngle(targetPos, arrow):
% 	# Flatten target to 90 deg corners using targetPos.
% 	# Find angle between x0,y0 and the arrow.
% 	return angle