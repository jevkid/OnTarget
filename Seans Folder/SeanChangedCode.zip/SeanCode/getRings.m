function r = getRings(imgPath)

users = {'Red', 'Blue', 'Green', 'Yellow', 'White'; 1 2 3 4 5};
//Declare a 5:2 matrix
--------------------------------------------------------------------------------------
users = %What it looks like printed into easy to read form
'Red' 'Blue' 'Green' 'Yellow' 'White'
[ 1] [ 2] [ 3] [ 4] [ 5]
---------------------------------------------------------------------------------------

colour = 'Yellow'; %declaration
foundI = 0; %declaration

for i = 1 : length(users) %For loop to maximum vector length

matched = strcmp(users(1,i),colour); %Function to compare strings

if (matched == 1) %Matched equals 1 when the vector matches the colour string

foundI = i; %Assign if true
break
end
end

foundI %%print foundI whether found or not,this will then be returned.
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Function: getRings
%
% Called From: doVideoAnalysis, doImageAnalysis.
% Returns: An array of rings and their equations.
% Description: Draws rings around each section of the target so that findArrows can easily find the scores.
%
% PSEUDOCODE:
%
% getRings(img):
% 	targetPos = getTargetPos(img)
% 	rings[11] = targetPos[0];
% 	for i in xrange(0,10)):
% 		rings[i] = # Find position of each ring
% 	return rings