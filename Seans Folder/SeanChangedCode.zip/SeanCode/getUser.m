function r = getUser(users,arrow) //Users would be a cell object.

%%	Array shootingUsers;
%%  Colour from fletchling
%%	SetColours;

//colour =getColour(arrow)

users = {'Red', 'Blue', 'Green', 'Yellow', 'White'; 1 2 3 4 5};

for i = 1 : length(users)
    match = strcmp(users(1,i),'Yellow');
    
    if (match == 1)
    
        foundI = i
        
    end
end
%%	For each shootingUser : 
%%		Loop through shootingUsers until find the user with that colour
%%		Once colour matches a user,return that UserID


%% Array(Array[ID,Colour])

	r = foundI
   %r = "0001" returns ID of User.
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Function: getUser
%
% Called From: doVideoAnalysis, doImageAnalysis.
% Returns: The ID of the user that shot the arrow.
% Description: Finds the current user from the colour of the fletchings and the user array sent from the PHP script.

% 

%
% PSEUDOCODE:
%